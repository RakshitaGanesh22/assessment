import "./styles.css";
import Header from "./components/navBar";
import { ThemeProviderCustom } from "./components/Theme";
import HeroBanner from "./components/HeroSection.jsx";

export default function App() {
  return (
    <ThemeProviderCustom>
      <div className="App">
        <Header />
        <HeroBanner />
      </div>
    </ThemeProviderCustom>
  );
}
