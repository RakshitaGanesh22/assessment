import React from "react";
import { Box, Typography, Button } from "@mui/material";
import { styled } from "@mui/system";
import SeoImage from "./asset/SEO.png";

const GradientText = styled("span")({
  background: "linear-gradient(90deg, #539BFF, #C43FEB)",
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
});

export default function HeroBanner() {
  return (
    <Box
      sx={{
        background:
          "linear-gradient(132.77deg, #FFFFFF 55.44%, #4D95E1 71.32%, #8165E4 82.01%, #BD2CE8 94.69%)",
        p: 4,
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {/* Content Section */}
      <Box sx={{ maxWidth: "600px", textAlign: "center" }}>
        <Typography variant="h3" fontWeight="bold">
          Let’s <GradientText>innovation</GradientText> meets your{" "}
          <strong>excellence</strong>
        </Typography>
        <Typography sx={{ my: 2, color: "#6c757d" }}>
          Excellence refined, innovation ignited, the future starts here.
        </Typography>
        <Button
          variant="contained"
          sx={{
            backgroundColor: "#6b6ef9",
            color: "#fff",
            textTransform: "none",
            px: 4,
            py: 1.5,
            borderRadius: "20px",
          }}
        >
          Book an Appointment
        </Button>
      </Box>

      {/* Image Section */}
      <Box sx={{ mt: 4 }}>
        <img
          src={SeoImage}
          alt="SEO"
          style={{
            width: "100%",
            maxWidth: "450px",
          }}
        />
      </Box>

      {/* Footer Section */}
      <Box
        sx={{
          mt: 5,
          display: "flex",
          justifyContent: "space-around",
          width: "100%",
        }}
      >
        <Box textAlign="center">
          <Typography variant="h5" fontWeight="bold">
            24/7
          </Typography>
          <Typography>Online Support</Typography>
        </Box>
        <Box textAlign="center">
          <Typography variant="h5" fontWeight="bold">
            100+
          </Typography>
          <Typography>Web Developed & Application</Typography>
        </Box>
        <Box textAlign="center">
          <Typography variant="h5" fontWeight="bold">
            5+
          </Typography>
          <Typography>Year Experience</Typography>
        </Box>
      </Box>
    </Box>
  );
}
