import React from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Menu,
  MenuItem,
  useMediaQuery,
  Box,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { useTheme } from "@mui/material/styles";
import logo from "./asset/logoP.png";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

const Header = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  return (
    <AppBar
      position="static"
      sx={{
        backgroundColor: "white",
        boxShadow: "none",
        padding: "10px 20px",
        fontFamily: "Poppins",
      }}
    >
      <Toolbar
        sx={{
          display: "flex",
          justifyContent: "space-around",
        }}
      >
        <img
          src={logo}
          alt="Phanom Professionals"
          style={{ width: !isMobile ? "13.25rem" : "8.625rem" }}
        />

        {isMobile ? (
          <Box>
            <IconButton edge="centre" color="inherit" onClick={handleMenuOpen}>
              <MenuIcon sx={{ color: "#6A49F2" }} />
            </IconButton>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
              sx={{
                width: "85vw",
                "& .MuiPaper-root": {
                  background:
                    "linear-gradient(151.54deg, #FFFFFF 59.85%, #A5CEEE 80.94%, #B38EEC 96.12%, #E789F4 107.8%)",
                },
              }}
            >
              <MenuItem onClick={handleMenuClose}>
                <Typography variant="h6" component="h6">
                  Service
                  <IconButton>
                    <KeyboardArrowDownIcon />
                  </IconButton>
                </Typography>
              </MenuItem>
              <MenuItem onClick={handleMenuClose}>
                <Typography variant="h6" component="h6">
                  Hire Indian Talent
                  <IconButton>
                    <KeyboardArrowDownIcon />
                  </IconButton>
                </Typography>
              </MenuItem>
              <MenuItem onClick={handleMenuClose}>
                <Typography variant="h6" component="h6">
                  Our Portfolio
                </Typography>
              </MenuItem>
              <MenuItem onClick={handleMenuClose}>
                <Button
                  variant="contained"
                  sx={{
                    backgroundColor: "#6A49F2",
                    color: "white",
                    borderRadius: "1rem",
                  }}
                >
                  <Typography variant="h6" component="h6">
                    Book an Appointment
                  </Typography>
                </Button>
                <Box
                  sx={{
                    position: "absolute",
                    top: -150,
                    right: 0,
                    zIndex: 1000,
                  }}
                >
                  <Box
                    sx={{
                      height: "111px",
                      width: "80px",
                    }}
                  >
                    <Box
                      sx={{
                        height: "74px",
                        width: "75px",
                        background:
                          "linear-gradient(180deg, #C1DAF4 0%, #6E76E3 100%)",
                        borderRadius: "50%",
                        position: "absolute",
                        top: "-37px",
                        right: "-37px",
                      }}
                    />
                    <Box
                      sx={{
                        height: "37px",
                        width: "37px",
                        background:
                          "linear-gradient(180deg, rgba(160, 70, 230, 0.15) 0%, #BE2AE8 100%)",
                        borderRadius: "50%",
                        position: "absolute",
                        bottom: "50px",
                        left: "20px",
                      }}
                    />
                  </Box>
                </Box>
              </MenuItem>
            </Menu>
          </Box>
        ) : (
          <Box sx={{ display: "flex", justifyContent: "space-around" }}>
            <Button sx={{ color: "black" }}>
              <Typography variant="h6" component="h6">
                Service
                <IconButton>
                  <KeyboardArrowDownIcon />
                </IconButton>
              </Typography>
            </Button>
            <Button sx={{ color: "black" }}>
              <Typography variant="h6" component="h6">
                Hire Indian Talent
                <IconButton>
                  <KeyboardArrowDownIcon />
                </IconButton>
              </Typography>
            </Button>
            <Button sx={{ color: "black" }}>
              <Typography variant="h6" component="h6">
                Our Portfolio
              </Typography>
            </Button>
            <Button sx={{ color: "black" }}>
              <Typography variant="h6" component="h6">
                Case Study
              </Typography>
            </Button>
            <Button
              variant="contained"
              sx={{
                backgroundColor: "#6A49F2",
                color: "white",
                borderRadius: "20px",
                margin: "10px",
                left: 30,
              }}
            >
              <Typography variant="h6" component="h6">
                Book an Appointment
              </Typography>
            </Button>
            <Box
              sx={{
                position: "fixed",
                top: 0,
                right: 0,
                zIndex: 1000,
              }}
            >
              <Box
                sx={{
                  height: "111px",
                  width: "80px",
                }}
              >
                <Box
                  sx={{
                    height: "74px",
                    width: "75px",
                    background:
                      "linear-gradient(180deg, #C1DAF4 0%, #6E76E3 100%)",
                    borderRadius: "50%",
                    position: "absolute",
                    top: "-37px",
                    right: "-37px",
                  }}
                />
                <Box
                  sx={{
                    height: "37px",
                    width: "37px",
                    background:
                      "linear-gradient(180deg, rgba(160, 70, 230, 0.15) 0%, #BE2AE8 100%)",
                    borderRadius: "50%",
                    position: "absolute",
                    bottom: "50px",
                    left: "20px",
                  }}
                />
              </Box>
            </Box>
          </Box>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Header;
